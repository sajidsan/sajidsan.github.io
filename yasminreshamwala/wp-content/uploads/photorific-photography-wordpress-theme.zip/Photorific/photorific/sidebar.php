<div id="sidebar">
	<?php generated_dynamic_sidebar('Default Sidebar') ?>
</div>