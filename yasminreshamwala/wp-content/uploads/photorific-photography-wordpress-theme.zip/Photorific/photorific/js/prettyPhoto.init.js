$(document).ready(function(){
	$("a[rel^='prettyPhoto']").prettyPhoto({
		theme: 'dark_rounded'	
	});
});