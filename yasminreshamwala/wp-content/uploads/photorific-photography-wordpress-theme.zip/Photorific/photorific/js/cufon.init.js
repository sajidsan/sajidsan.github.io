$(document).ready(function(){ 
Cufon.replace('#sitename');
Cufon.replace('#sf-menu ul li a');
Cufon.replace('#footer h3');
Cufon.replace('#page li h2');
Cufon.replace('.post_meta');
Cufon.replace('.button');
Cufon.replace('h1', {hover: true});
Cufon.replace('h2', {hover: true});
Cufon.replace('h3', {hover: true});
Cufon.replace('h4', {hover: true});
Cufon.replace('h5', {hover: true});
Cufon.replace('h6', {hover: true});
});