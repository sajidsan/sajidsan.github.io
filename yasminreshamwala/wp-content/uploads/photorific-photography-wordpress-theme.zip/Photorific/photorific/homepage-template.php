<?php 
/*
Template Name: Homepage
*/
get_header(); ?>


<?php get_footer(); ?>